package com.example.hristo.musicorganizer;

import android.content.Context;
import android.widget.MediaController;

/**
 * Created by Hristo on 4/12/2018.
 */

// стандартен Widget class за да визуализира бутоните за play skip forward
public class MusicController extends MediaController {

    public MusicController(Context c){
        super(c);
    }

    public void hide(){}

}
