package com.example.hristo.musicorganizer;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Handler;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.r0adkll.slidr.Slidr;

import java.nio.channels.Selector;
import java.util.Random;

public class RecordSound extends AppCompatActivity {
    private MediaRecorder myRecorder;
    private MediaPlayer myPlayer;
    private String outputFile = null;
    private ImageButton record_start_stop_Btn;
    private ImageButton play_stop_start_Btn;
    private TextView text;
    private boolean isRecording = false;
    private boolean isPlaying = false;
    private boolean makeClickable= false;
    private int maxRandomStringLenght=20;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_sound);
        text = (TextView) findViewById(R.id.text1);

        myRecorder = new MediaRecorder();
        myRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        myRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        myRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);

        myPlayer = new MediaPlayer();

        play_stop_start_Btn = (ImageButton)findViewById(R.id.play);
        play_stop_start_Btn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                    if (makeClickable) {
                        if (!isPlaying) {
                            record_start_stop_Btn.setClickable(false);
                            record_start_stop_Btn.setBackgroundResource(R.drawable.record_disabled);
                            play();
                            play_stop_start_Btn.setBackgroundResource(R.drawable.stop);
                        } else {
                            stopPlay();
                            record_start_stop_Btn.setClickable(true);
                            record_start_stop_Btn.setBackgroundResource(R.drawable.record);
                            play_stop_start_Btn.setBackgroundResource(R.drawable.playrec);
                        }
                        isPlaying = !isPlaying;
                    }
            }
        });

        record_start_stop_Btn = (ImageButton)findViewById(R.id.start);
        record_start_stop_Btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                    if(!myPlayer.isPlaying()) {
                        if (!isRecording) {
                            outputFile = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + random() + ".3gpp";
                            myRecorder.setOutputFile(outputFile);
                            start(v);
                            record_start_stop_Btn.setBackgroundResource(R.drawable.stop);
                            play_stop_start_Btn.setClickable(false);
                            makeClickable=false;
                            play_stop_start_Btn.setBackgroundResource(R.drawable.disabled_play);
                        } else {
                            stop(v);
                            record_start_stop_Btn.setBackgroundResource(R.drawable.record);
                            play_stop_start_Btn.setClickable(true);
                            makeClickable=true;
                            play_stop_start_Btn.setBackgroundResource(R.drawable.playrec);
                        }
                        isRecording = !isRecording;
                    }
            }
        });

        try{
            myPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    stopPlay();
                    play_stop_start_Btn.setBackgroundResource(R.drawable.playrec);
                    isPlaying = !isPlaying;
                    record_start_stop_Btn.setClickable(true);
                    record_start_stop_Btn.setBackgroundResource(R.drawable.record);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
        Slidr.attach(this);
    }

    private String random(){
        Random rand=new Random();
        String possibleLetters = "0123456789abcdefghijklmnopqrstuvwxyz";
        StringBuilder sb = new StringBuilder(maxRandomStringLenght);
        for(int i = 0; i < maxRandomStringLenght; i++)
            sb.append(possibleLetters.charAt(rand.nextInt(possibleLetters.length())));
        return sb.toString();
    }

    public void start(View view){
        try {
            myRecorder.prepare();
            myRecorder.start();

        } catch (IllegalStateException e) {
            // start:it is called before prepare()
            // prepare: it is called after start() or before setOutputFormat()
            e.printStackTrace();
        } catch (IOException e) {
            // prepare() fails
            e.printStackTrace();
        }catch (Exception e) {
            e.printStackTrace();
        }
        Toast.makeText(getApplicationContext(), "Start recording...", Toast.LENGTH_SHORT).show();
    }
    public void stop(View view){
        try {
            myRecorder.stop();
            myRecorder.reset();
            myRecorder.release();

            myRecorder = new MediaRecorder();
            myRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            myRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            myRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);

            Toast.makeText(getApplicationContext(), "Stop recording...", Toast.LENGTH_SHORT).show();
        } catch (IllegalStateException e) {
            //  it is called before start()
            e.printStackTrace();
        } catch (RuntimeException e) {
            // no valid audio/video data has been received
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void play() {
        try{
            myPlayer.setDataSource(outputFile);
            myPlayer.prepare();
            myPlayer.start();

            Toast.makeText(getApplicationContext(), "Start play the recording...", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void stopPlay() {
        try {
                myPlayer.stop();
                myPlayer.reset();

                Toast.makeText(getApplicationContext(), "Stop playing the recording...", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
