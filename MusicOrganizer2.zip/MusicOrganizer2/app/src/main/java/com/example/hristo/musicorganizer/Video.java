package com.example.hristo.musicorganizer;

/**
 * Created by Hristo on 4/24/2018.
 */

public class Video {

    private String videoUrl;

    public Video(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }
}
