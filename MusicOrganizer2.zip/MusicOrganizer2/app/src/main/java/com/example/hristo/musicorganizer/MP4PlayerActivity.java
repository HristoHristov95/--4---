package com.example.hristo.musicorganizer;

import android.content.CursorLoader;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.ListView;

import com.r0adkll.slidr.Slidr;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class MP4PlayerActivity extends AppCompatActivity {
    private ListView mVideosListView;
    private List<Video> mVideosList = new ArrayList<>();
    private VideoAdapter mVideoAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mp4_player);

        //assign video
        mVideosListView = (ListView) findViewById(R.id.videoListView);

        try {
            ArrayList<String> list=getAllMedia();
            MediaMetadataRetriever retriever = new MediaMetadataRetriever();

            for(String i : list)
            {
                retriever.setDataSource(this, Uri.parse(i));

                String hasVideo = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO);
                boolean isVideo = "yes".equals(hasVideo);
                if(isVideo) {
                    mVideosList.add(new Video(i));
                }
            }


        }catch (Exception e)
        {
            e.printStackTrace();
        }

        /***populate video list to adapter**/
        mVideoAdapter = new VideoAdapter(this, mVideosList);
        mVideosListView.setAdapter(mVideoAdapter);

        Slidr.attach(this);
    }

    public ArrayList<String> getAllMedia() {
        ArrayList<String> list=new ArrayList<>();
        Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        String[] projection = { MediaStore.Video.VideoColumns.DATA };
        Cursor c = this.getContentResolver().query(uri, projection, null, null, null);
        if (c != null) {
            while (c.moveToNext()) {
                list.add(c.getString(0));
            }
            c.close();
        }
        return list;
    }

}
